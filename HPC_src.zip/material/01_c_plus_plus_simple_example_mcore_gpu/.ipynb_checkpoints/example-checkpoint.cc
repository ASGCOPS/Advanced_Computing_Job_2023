
#include <vector>
#include <iostream>
#include <fstream>
#include <random>
#include <string>

#include <algorithm>
#include <execution>



int main()
{
int N=4000;

std::vector<int> random_number;

// Create random value vector by CPU on system memory.    
for (int x=0;x<N;x++)
{
	int random_int;
	random_int=rand() % 90000;
	random_number.push_back(random_int);
}

// Sort random number with MCORE or GPU.

std::sort(std::execution::par, random_number.begin(), random_number.end());

    
// Print the sort result on screen.    
    
for (int i=0;i<20;i++)
{
	std::cout<<random_number[i]<<std::endl;
}

}

