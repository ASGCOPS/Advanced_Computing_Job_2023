//#include<omp.h>
#include<stdio.h>
//#include <iostream.h>
#include <stdlib.h>

using namespace std;

#define N 2000000000

int main()
{       
    //Single core or CPU session :
        int* a = (int*)malloc(sizeof(int) * N);
        int* b = (int*)malloc(sizeof(int) * N);
        int* c = (int*)malloc(sizeof(int) * N);
        
        for (int i = 0; i < N; i++)
        {
                a[i] = 9;
                b[i] = 1;
                c[i] = 0;
        }
    
    
    // Multi-core or GPU session :
    #pragma omp target device(0) map(to: a[0:N-1]) map(to: b[0:N-1]) map(from: c[0:N-1])
        {

        #pragma omp teams distribute parallel for    
        for (int i = 0; i < N; i++)
                c[i] += a[i] + b[i];
        

        }
}
