// openmp reduction test

#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#define COUNT 200000000
 
int main()  
{
	int sum = 0;		// Assign an initial value on system memory.
    
   #pragma omp target map(to: sum) map(from: sum)
    {       
    #pragma omp teams distribute parallel for reduction(+:sum)
	for(int i = 0;i < COUNT; i++) 
	{
        // Edit your own formula here:
        sum += rand() % 3;
	}
        
    }
    
	printf("\n Sum: %d\n\n",sum);

	return 0;  
}
